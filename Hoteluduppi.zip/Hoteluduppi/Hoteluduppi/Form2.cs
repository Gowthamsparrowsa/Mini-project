﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hoteluduppi
{
    public partial class Form2 : Form
    {
        public Form2()
        {
           
            InitializeComponent();
        }//connection Estabishment
        SqlConnection con = new SqlConnection(@"Data Source =(localdb)\MSSQLLocalDB;Initial Catalog=Hotel;Integrated Security=True");

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hotelDataSet.foods' table. You can move, or remove it, as needed.
            this.foodsTableAdapter.Fill(this.hotelDataSet.foods);



        }

        private void button5_Click(object sender, EventArgs e)
        {
            String q = "select * from foods";
            SqlCommand cmd = new SqlCommand(q, con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt= new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
            
          

        }

        private void button1_Click(object sender, EventArgs e)
        {
             String name = textBox2.Text;
            String type = comboBox1.Text;
            int price = int.Parse(textBox3.Text);
            String favail = comboBox2.Text;
            String query = "insert into foods(fname,ftype,fprice,favail) values('" + name + "','" + type + "'," + price + ",'" + favail + "')";
            //create statement
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int r = cmd.ExecuteNonQuery();
            con.Close();
            if (r > 0){
                MessageBox.Show("Registered");
            }
            else
            {
                MessageBox.Show("Failed");
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int i = int.Parse(textBox1.Text);
            String name = textBox2.Text;
            String type = comboBox1.Text;
            int price = int.Parse(textBox3.Text);
            String favail = comboBox2.Text;
            String query = "update foods set fname ='" + name + "',ftype='" + type + "' ,fprice=" + price + ",favail='" + favail + "'where fid=" + i;
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int r = cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show((r > 0) ? "updated" : "not updated");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i = int.Parse(textBox1.Text);
            String query = " delete from foods where fid=" + i;
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int r = cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show((r > 0) ? "Deleted" : "not deleted");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int i = int.Parse(textBox1.Text);
            String query = "select fname,ftype,fprice,favail from foods where fid=" + i;
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox2.Text = dr["fname"].ToString();
                comboBox1.Text = dr["ftype"].ToString();
                textBox3.Text = dr["fprice"].ToString();
                comboBox2.Text = dr["favail"].ToString();
            }con.Close();

        }
    }
}
